<?php

namespace Symfony\Component\Debug\Tests\Fixtures;

/**
 * @internal
 */
interface InternalInterface
{
}
